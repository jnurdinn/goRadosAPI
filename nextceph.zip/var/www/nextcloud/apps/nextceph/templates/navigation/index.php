<ul>
        <li>
                <a href="">Dashboard</a>
                <ul>
                        <li><a href="." class="icon-category-monitoring">Overall Stats</a></li>
                        <li><a href="log" class="icon-menu">Cluster Log</a></li>
                </ul>
        </li>
        <li>
                <a href="#">Cluster</a>
                <ul>
                        <li><a href="crush" class="icon-user">CRUSH & Erasure Profile</a></li>
                        <li><a href="host" class="icon-desktop">Hosts</a></li>
                        <li><a href="pool" class="icon-toggle-background">Pools</a></li>
                        <li><a href="osd" class="icon-category-office">OSDs</a></li>
                        <li><a href="mon" class="icon-video">MONs</a></li>
                        <li><a href="config" class="icon-settings-dark">Config</a></li>
                </ul>
        </li>
        <li>
                <a href="#">Services</a>
                <ul>
                        <li><a href="cephfs" class="icon-files-dark">CephFS</a></li>
                        <li><a href="rbd" class="icon-toggle-pictures">Rados Block Device</a></li>
                        <li><a href="rgw" class="icon-category-integration">Rados Gateway</a></li>
                </ul>
        </li>
</ul>
