<?php
script('nextceph', 'script');
style('nextceph', 'style');
?>

<div id="app">
	<div id="app-navigation">
		<?php print_unescaped($this->inc('navigation/index')); ?>
		<?php print_unescaped($this->inc('settings/index')); ?>
	</div>

	<div id="app-content">
		<div id="app-content-wrapper">
			<div id="container">
				<main>
					<pre><H1>Ceph FS
					</H1><table><tr><th><b>FS Name</b></th>
					<th><b>Metadata Pool</b></th>
					<th><b>Data Pool</b></th>
					<th><b>MDS Node</b></th></tr>
						<?php
						function get($url){
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL,$url);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
							$result = curl_exec($ch);
							$data = json_decode($result);
							return $data;
						}
						$data = get('http://10.10.2.103:8080/cephfs');
						echo "<tr>";
						echo "<td><b>".$data->fsname."</b></td>";
						echo "<td>".$data->metadatapool."</td>";
						echo "<td>";
						foreach ($data->datapools as $datas){
							echo $datas.' ';
						}
						echo "</td>";
						echo "<td>".$data->mdsnode."</td>";
						echo "</tr>";
						echo('');
						?>
			</table></pre></main></div>
		</div>
	</div>
</div>
