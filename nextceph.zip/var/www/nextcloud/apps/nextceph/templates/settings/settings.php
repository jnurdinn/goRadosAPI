<?php
  $nc_config = array(
    'user' => 'admin',
    'psswd' => 'fd376672-e167-4afb-b9ef-8f73aa96b7bb',
    'mgr_host' => '10.10.2.102',
    'mgr_port' => '9001',
  );
