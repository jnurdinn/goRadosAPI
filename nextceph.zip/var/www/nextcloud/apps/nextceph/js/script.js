function form {
  alert("Hello! I am an alert box!!");
}
